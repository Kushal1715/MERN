let productContainer = document.querySelector('.products');
let title = document.querySelector('#title')
let desc = document.querySelector('#desc')
let result = "";
async function getProducts() {
  try {
    const productName = document.querySelector('#input').value;
    const url = await fetch(`https://dummyjson.com/products/search?q=${productName}`);
    const data = await url.json();
    let products = data.products;

    let result = "";
    products.forEach((product) => {
      let desc = product.description.slice(0, 88);
      result += `<div class="products">
        <img src="${product.thumbnail}" id="image"/>
        <h3 id="title">${product.title}</h3>
        <p id="desc">${desc}...</p>
      </div>`;
      // console.log(result);
      document.querySelector(".section2").innerHTML = result;
    });
    console.log(products);
  } catch (e) {
    console.log(e);
  }
}

